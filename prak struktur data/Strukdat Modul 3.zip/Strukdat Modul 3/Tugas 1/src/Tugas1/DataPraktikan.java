package Tugas1;

import java.util.HashSet;
import java.util.Scanner;
import java.util.HashMap;

public class DataPraktikan {
    static HashMap<String, String> TabelData = new HashMap<>();
    static HashMap<String, String> TabelSesiLogin = new HashMap<>();
    static HashSet<String> DataAsisten = new HashSet<>();
    static Scanner input = new Scanner(System.in);
    static int respon;
    static boolean error, loop;

    static String[] nama = {"VIRGIAWAN SAGARMATA P.", "WAHYU BUDI U.", "SALSABILA AULIA R.", "FARKHAN HAMZAH F."};

    public static void main(String[] args) {
        String inputEmail, inputPass;

        TabelSesiLogin.put("nurulmaudy28@umm.ac.id", "InformatikaUMM");
        TabelSesiLogin.put("nurulmaudyfadillah.@umm.ac.id", "Informatika");

        for (int i = 440; i <= 449; i++) {
            TabelData.put("IF2020" + i, nama[randomWithRange(0, nama.length - 1)]);
        }

        System.out.println("\nPraktikan Modul 3 Struktur Data.");

        do {
            error = false;
            System.out.println();
            System.out.println("Email\t\t: ");
            inputEmail = input.nextLine();
            System.out.println("Password\t: ");
            inputPass = input.nextLine();
            System.out.println();

            login(inputEmail, inputPass);

        }
        while (error);
        {
            System.out.println("Email Dan Password Anda Salah !!");
        }

        input.close();
    }

    public static void login(String inputEmail, String inputPass) {
        if (TabelSesiLogin.containsKey(inputEmail) && TabelSesiLogin.get(inputEmail).equals(inputPass)) {
            if (inputEmail.contains("@umm.ac.id")) {
                error = false;
                char[] Nama = inputEmail.toCharArray();
                System.out.println("Selamat Datang");
                for (int i = 0; Nama[i] != '@'; i++) {
                    System.out.print(Nama[i]);
                }
                System.out.println(" !!\n\n");
                menu();
            } else {
                System.out.println("Email Harus Menggunakan Domain @umm.ac.id !");
                error = true;
            }
        }
    }

    public static void menu() {
        while(true) {
            loop = true;
            String Nim, Asisten;
            System.out.print("""
                    === Menu Data Praktikum ===
                    1.) List Semua Data
                    2.) List Nim Terdaftar
                    3.) List Nama Asisten Terdaftar
                    4.) Tambah Data
                    5.) Hapus Data
                    6.) Edit Data
                    7.) Search Data
                    8.) Total Data
                    9.) Keluar
                                    
                    Pilih Menu : """);
            respon = input.nextInt();
            input.nextLine();

            System.out.println();

            if (respon == 1) {
                Tampil();
            } else if (respon == 2) {
                listNimPraktikum();
            } else if (respon == 3) {
                listNamaAsisten();
            } else if (respon == 4) {
                System.out.println("========== Tambah Data ==========");
                System.out.println("Masukkan NIM Praktikan : ");
                Nim = input.nextLine();
                System.out.println("Masukkan Nama Asisten : ");
                Asisten = input.nextLine();
                System.out.println();
                TambahData(Nim, Asisten);
            } else if (respon == 5) {
                System.out.println("========== Hapus Data ==========");
                System.out.println("Masukkan NIM Praktikan dan Nama Asisten Yang Mau Dihapus !");
                System.out.println("Masukkan NIM Praktikan : ");
                Nim = input.nextLine();
                System.out.println("Masukkan Nama Asisten : ");
                Asisten = input.nextLine();
                HapusData(Nim, Asisten);
            } else if (respon == 6) {
                System.out.println("========== Edit Data ==========");
                System.out.println("Masukkan NIM Praktikan Yang Mau Di Edit : ");
                Nim = input.nextLine();
                System.out.println("Masukkan Nama Asisten Baru : ");
                Asisten = input.nextLine();
                EditData(Nim, Asisten);
            } else if (respon == 7) {
                System.out.println("========== Search Data ==========");
                System.out.println("Mencari NIM Praktikan Dengan Asisten Yang Sama : ");
                System.out.println("Masukkan Nama Asisten : ");
                Asisten = input.nextLine();
                Search(Asisten);
            } else if (respon == 8) {
                System.out.println("Total Data Yang Tersimpan : " + TotalEmail());
                System.out.println();
            } else if (respon == 9) {
                System.out.println("=== Selesai ===");
                logout();
                return;
            } else {
                System.out.println("Perintah Diluar Kemampuan Program !");
            }
        }
    }

    private static void logout() {
        loop = false;
    }

    private static int TotalEmail() {
        return TabelData.size();
    }

    private static void Search(String NamaAsisten) {
        int i = 1;
        System.out.println("List NIM Dengan Asisten " + NamaAsisten + " : ");
        for (String s : TabelData.keySet()) {
            if (TabelData.get(s).equals(NamaAsisten)) {
                System.out.println(i + ". " + s);
                i++;
            }
        }
        System.out.println();
    }

    private static void EditData(String NimPraktikum, String NamaAsisten) {
        if (!TabelData.containsKey(NimPraktikum)) {
            System.out.println("Data Tidak Terdaftar !\n");
        } else {
            TabelData.replace(NimPraktikum, NamaAsisten);
            System.out.println("Data Berhasil Diupdate !\n");
        }
    }

    private static void HapusData(String NimPraktikum, String NamaAsisten) {
        if (!TabelData.containsKey(NimPraktikum) || !TabelData.get(NimPraktikum).equals(NamaAsisten)) {
            System.out.println("Data Yang Mau Dihapus Tidak Terdaftar !\n");
        } else {
            TabelData.remove(NimPraktikum, NamaAsisten);
            System.out.println("Data Sukses Dihapus !\n");
        }
    }

    private static void TambahData(String NimPraktikum, String NamaAsisten) {
        if (!(NimPraktikum.contains("IF"))) {
            System.out.println("Data Harus Memiliki Kombinasi Nama IF !\n");
        } else if (TabelData.containsKey(NimPraktikum)) {
            System.out.println("Gagal Menambah Data");
            System.out.println("Data Dengan NIM " + NimPraktikum + "Sudah Terdaftar !\n");
        } else {
            TabelData.put(NimPraktikum, NamaAsisten);
            System.out.println("Data Sukses Ditambahkan !\n");
        }
    }

    private static void listNamaAsisten() {
        DataAsisten.addAll(TabelData.values());
        System.out.println("========== List Nama Asisten ==========");
        int i = 1;
        for (String s : DataAsisten) {
            System.out.println(i + ". " + s);
            i++;
        }
        System.out.println();
    }

    private static void listNimPraktikum() {
        System.out.println("========== List NIM Praktikan ==========");
        int i = 1;
        for (String s : TabelData.keySet()) {
            if (i < 10){
                System.out.println(i + ".  " + s);
            }
            else{
                System.out.println(i + ". " + s);
            }
            i++;
        }
        System.out.println();
    }

    private static void Tampil() {
        System.out.println("========== List Data ==========");
        System.out.println("Total Data Yang Tersimpan : " + TotalEmail());
        System.out.println("No.\t\tNIM Praktikan. \t\tNama Asisten. ");

        int i = 1;
        for (String s : TabelData.keySet()) {
            if (i < 10){
                System.out.println(i + ". \t\t" + s + " \t\t\t" + TabelData.get(s));
            }
            else{
                System.out.println(i + ".\t\t" + s + " \t\t\t" + TabelData.get(s));
            }
            i++;
        }
        System.out.println();
    }

    public static int randomWithRange(int min, int max) {
        int range = (max - min) + 1;
        return (int) (Math.random() * range) + min;
    }
}